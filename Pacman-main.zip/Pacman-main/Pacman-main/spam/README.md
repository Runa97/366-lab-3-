Spam Classifier

Project 1: Spam Classifier
-----------------------------

Version 1.000

TODO: Finish writing this up
*** DO NOT EDIT IN THE SOLUTION BRANCH ***
Only edit in master so that we can merge!

* * *

### Table of Contents

*   [Introduction](#Introduction)
*   [Welcome](#Welcome)
*   [Code to write](#Code)


Basically, check out the Wikipedia page


Put the data for download into Google Drive (docs.zip)

Questions to answer about the spam messages

### Introduction

What is a Markov process?
Visual of a state diagram
Example with some text
Possibly some helpful text
Link to some decent videos

### Welcome

### Code

### Other sections